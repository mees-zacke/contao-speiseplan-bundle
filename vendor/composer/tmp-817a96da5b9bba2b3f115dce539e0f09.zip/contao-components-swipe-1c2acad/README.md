Swipe
=====

This is a fork of the [Swipe project][1] originally developed by Brad Birdsall
and released under the [MIT license][2] (see the [original project][3]).

The fork additionally contains a dot menu to directly jump to a certain slide.
The script is to be integrated in [Contao Open Source CMS][4].


[1]: http://swipejs.com
[2]: http://opensource.org/licenses/MIT
[3]: https://github.com/thebird/Swipe
[4]: https://contao.org
