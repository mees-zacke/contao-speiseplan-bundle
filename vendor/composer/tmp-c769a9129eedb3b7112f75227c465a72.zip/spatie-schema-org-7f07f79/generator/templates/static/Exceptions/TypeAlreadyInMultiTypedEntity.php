<?php

namespace Spatie\SchemaOrg\Exceptions;

use InvalidArgumentException;

class TypeAlreadyInMultiTypedEntity extends InvalidArgumentException
{
}
