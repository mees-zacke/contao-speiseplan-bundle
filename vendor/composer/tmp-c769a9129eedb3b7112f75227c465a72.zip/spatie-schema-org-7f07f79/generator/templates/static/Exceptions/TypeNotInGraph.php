<?php

namespace Spatie\SchemaOrg\Exceptions;

use InvalidArgumentException;

class TypeNotInGraph extends InvalidArgumentException
{
}
