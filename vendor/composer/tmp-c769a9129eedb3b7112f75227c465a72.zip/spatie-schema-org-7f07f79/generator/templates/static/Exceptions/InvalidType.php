<?php

namespace Spatie\SchemaOrg\Exceptions;

use InvalidArgumentException;

class InvalidType extends InvalidArgumentException
{
}
