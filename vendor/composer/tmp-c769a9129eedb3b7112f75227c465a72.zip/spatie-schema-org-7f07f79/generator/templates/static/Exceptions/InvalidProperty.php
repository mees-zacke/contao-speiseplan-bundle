<?php

namespace Spatie\SchemaOrg\Exceptions;

use Exception;

class InvalidProperty extends Exception
{
}
