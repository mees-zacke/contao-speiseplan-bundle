<?php

return [
    'Names' => [
        'NGN' => [
            '₦',
            'Nigerian Naira',
        ],
    ],
];
