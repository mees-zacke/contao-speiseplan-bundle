<?php

return [
    'Names' => [
        'SLE' => [
            'Le',
            'Sierra Leonean Leone',
        ],
    ],
];
