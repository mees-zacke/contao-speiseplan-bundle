<?php

return [
    'Names' => [
        'PAB' => [
            'B/.',
            'balboa panameño',
        ],
    ],
];
