<?php

return [
    'Names' => [
        'BSD' => [
            '$',
            'Bahamian Dollar',
        ],
    ],
];
