<?php

return [
    'Names' => [
        'MWK' => [
            'MK',
            'Malawian Kwacha',
        ],
    ],
];
