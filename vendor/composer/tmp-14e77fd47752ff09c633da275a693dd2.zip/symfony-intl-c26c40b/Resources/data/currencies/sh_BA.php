<?php

return [
    'Names' => [
        'BAM' => [
            'KM',
            'Bosanskohercegovačka konvertibilna marka',
        ],
        'BYN' => [
            'BYN',
            'Bjeloruska rublja',
        ],
        'KPW' => [
            'KPW',
            'Sjevernokorejski von',
        ],
        'NIO' => [
            'NIO',
            'Nikaragvanska zlatna kordoba',
        ],
    ],
];
