<?php

return [
    'Names' => [
        'CLP' => [
            '$',
            'Peso chileno',
        ],
        'USD' => [
            'US$',
            'dólar estadounidense',
        ],
    ],
];
