<?php

return [
    'Names' => [
        'MDL' => [
            'L',
            'молдавский лей',
        ],
    ],
];
