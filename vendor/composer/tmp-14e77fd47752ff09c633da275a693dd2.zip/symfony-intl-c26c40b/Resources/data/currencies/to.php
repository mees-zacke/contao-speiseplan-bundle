<?php

return [
    'Names' => [
        'AUD' => [
            'AUD$',
            'Tola fakaʻaositelēlia',
        ],
        'EUR' => [
            '€',
            'ʻEulo',
        ],
        'FJD' => [
            'FJD',
            'Tola fakafisi',
        ],
        'NZD' => [
            'NZD$',
            'Tola fakanuʻusila',
        ],
        'PGK' => [
            'PGK',
            'Kina fakapapuaniukini',
        ],
        'SBD' => [
            'SBD',
            'Tola fakaʻotusolomone',
        ],
        'TOP' => [
            'T$',
            'Paʻanga fakatonga',
        ],
        'VUV' => [
            'VUV',
            'Vatu fakavanuatu',
        ],
        'WST' => [
            'WST',
            'Tala fakahaʻamoa',
        ],
        'XPF' => [
            'CFPF',
            'Falaniki fakapasifika',
        ],
    ],
];
