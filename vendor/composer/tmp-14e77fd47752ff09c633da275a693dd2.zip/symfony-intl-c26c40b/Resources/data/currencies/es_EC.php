<?php

return [
    'Names' => [
        'USD' => [
            '$',
            'dólar estadounidense',
        ],
    ],
];
