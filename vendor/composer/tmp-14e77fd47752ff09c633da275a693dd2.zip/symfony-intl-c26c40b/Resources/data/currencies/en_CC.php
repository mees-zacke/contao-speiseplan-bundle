<?php

return [
    'Names' => [
        'AUD' => [
            '$',
            'Australian Dollar',
        ],
    ],
];
