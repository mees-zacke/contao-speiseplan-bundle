<?php

return require(__DIR__.'/vendor/contao/easy-coding-standard/config/self.php');
