Mediabox
========

This is a customized MooTols [mediabox][1] package to be integrated in
[Contao Open Source CMS][2].


[1]: https://github.com/iaian7/mediaboxAdvanced/
[2]: https://contao.org
